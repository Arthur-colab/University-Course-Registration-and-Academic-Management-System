# University Management

A small Spring Boot project for learning Java, JPA, and PostgreSQL. It defines
departments, students, student profiles, lecturers, courses, and registrations.
Spring Data repositories provide basic database operations; no extra service or
web API layers are included yet.

## Requirements

- Java 25 (as configured in `pom.xml`)
- PostgreSQL

## 1. Create the database

Open PostgreSQL or pgAdmin and run:

```sql
CREATE DATABASE university_academic_db;
```

## 2. Configure the connection

The default settings in `src/main/resources/application.properties` assume:

- PostgreSQL is running on `localhost:5432`
- Database: `university_academic_db`
- Username: `postgres`
- Password: `postgres`

Change those defaults in `application.properties`, or set the `DB_URL`,
`DB_USERNAME`, and `DB_PASSWORD` environment variables before starting the app.
Do not commit a real database password to source control.

## 3. Run the application

From the project directory in PowerShell:

```powershell
.\mvnw.cmd spring-boot:run
```

The first run creates or updates the database tables automatically. The
application is not an HTTP API yet; use the repositories from Java code or add
controllers as a next learning step.

## Project structure

```text
src/main/java/com/university/
├── UniversityManagementApplication.java
├── model/
└── repository/
```
