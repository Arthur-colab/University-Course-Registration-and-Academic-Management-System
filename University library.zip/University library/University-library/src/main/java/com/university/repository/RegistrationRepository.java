package com.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.university.model.Registration;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {
}
