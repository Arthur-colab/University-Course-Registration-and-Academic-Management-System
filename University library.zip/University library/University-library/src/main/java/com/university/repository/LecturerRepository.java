package com.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.university.model.Lecturer;

public interface LecturerRepository extends JpaRepository<Lecturer, Long> {
}
