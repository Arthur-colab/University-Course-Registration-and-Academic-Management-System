package com.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.university.model.StudentProfile;

public interface StudentProfileRepository extends JpaRepository<StudentProfile, Long> {
}
