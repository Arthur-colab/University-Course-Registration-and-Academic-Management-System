package com.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.university.model.Course;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
