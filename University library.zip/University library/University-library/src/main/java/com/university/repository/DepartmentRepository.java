package com.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.university.model.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}
