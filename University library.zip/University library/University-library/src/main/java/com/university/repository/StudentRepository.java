package com.university.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.university.model.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
}
